package com.persona.apipersona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApipersonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
