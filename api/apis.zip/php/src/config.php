<?php

$db = [
    'host' => 'localhost',
    'username' => '394737',
    'password' => '2605946449a',
    'db' => '394737' //Cambiar al nombre de tu base de datos
];

?>
