﻿namespace front_asp.Models
{
    public class CollectionModel
    {

        public List<_Comentario> listaComentarios { get; set; }
        public _Comentario comentario { get; set; }
    }
}
